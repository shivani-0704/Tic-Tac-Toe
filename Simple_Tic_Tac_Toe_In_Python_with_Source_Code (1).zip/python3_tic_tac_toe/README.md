# python3_tic_tac_toe
A self-learning project that create a simple Tic Tac Toe game in command-line with python 3

# Requirements: 
 * 2 players should be able to play the game (both sitting at the same computer)
 * The board should be printed out every time a player makes a move
 * You should be able to accept input of the player position and then place a symbol on the board
 * Use the numpad to make a move with the value of 1 to 9  + Enter
 * game will be restarted if you click '0' + Enter
 
# Instruction:
## option 1:
  * open the python console by typing `python` in the console.
  * Copy and paste the code in ttt.py to the console.
  * type `start()` to start the game

## option 2:
  * open the console and type `python ttt.py`
 
